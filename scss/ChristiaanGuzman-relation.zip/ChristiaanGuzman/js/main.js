
const buyProduct = document.querySelector('.main-class');

getProducts();

function getProducts() {
    buyProduct.addEventListener('click', AddProduct)
}

function AddProduct(e){
    e.preventDefault();
    const productSelected = e.target;
    readProduct(productSelected.parentElement);
}


function readProduct(productSelected) {
    const product = document.querySelector('.item');
    product.innerHTML = `you added ${productSelected.textContent} to your shopping car`
}





